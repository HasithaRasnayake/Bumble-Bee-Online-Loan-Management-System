"Bumble Bee" online loan management system created by R M H P B Rasnayake.

Administartor Login details- 
Username _ admin
Password - 1234

Customer Login details - 
Username - Hasitha
Password - Hasitha123